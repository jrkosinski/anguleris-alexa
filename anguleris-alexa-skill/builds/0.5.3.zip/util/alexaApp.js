'use strict';

const async = require('asyncawait/async');
const await = require('asyncawait/await');
const alexa = require("alexia");
const app = alexa.createApp('anguleris-alexa-skill', { shouldEndSessionByDefault: false });

const exception = require('anguleris-common').exceptions('APP');
const logger = require('anguleris-common').logger('APP');

const config = require('../config');
const pkg = require('../package.json');

function responseWithCard(text, title, shouldEndSession) {
    return {
        text: text,
        card: {
            title: title,
            content: text
        },
        shouldEndSession: shouldEndSession ? true: false
    };
}

app.onStart(() => {
    return exception.try(() => {
        return responseWithCard(config.ui.text.launchPrompt, config.ui.cards.launchPrompt); 
    });
});

app.intent(config.intents.getVersion.name,
    config.intents.getVersion.utterances,
    () => {
        return exception.try(() => {
            var versionText = config.ui.text.getVersion.replace('{version}', pkg.version);
            return responseWithCard(versionText, config.ui.cards.getVersion); 
        });
    }
);

module.exports = {
    app: app
};